from django.contrib import admin
from django.urls import path
from . import views

from django.conf.urls.static import static
from django.conf import settings

from django.contrib.auth import views as auth_views

from .views import *

urlpatterns = [
	#Leave as empty string for base url
	path('', views.store, name="store"),
	path('register/', views.registerPage, name="register"),
	path('login/', views.loginPage, name="login"),  
	path('logout/', views.logoutUser, name="logout"),
	path('cart/', views.cart, name="cart"),
	path('search/', SearchView.as_view(), name="search"),

	# path('collections/', views.collections, name="collections"),
	# path('collections/<str:slug>', views.collectionsview, name="collectionsview"),
	path('category_list',views.category_list,name='category-list'),
	path('category_product_list/<int:cat_id>',views.category_product_list,name='category-product-list'),
	path('product_detail/<int:cat_id>',views.product_detail,name='product-detail'),

	path('owlview/', OwlView.as_view(), name="owlview"),

	path('checkout/', views.checkout, name="checkout"),

	path('update_item/', views.updateItem, name="update_item"),
	path('process_order/', views.processOrder, name="process_order"),

	path('activate/<uidb64>/<token>', views.activate, name="activate")

]

urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)