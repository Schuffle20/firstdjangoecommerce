# EMAIL_BACKEND = 'django.core.mail.backends.smtp.EmailBackend'
EMAIL_USE_TLS = True
# EMAIL_HOST = 'smtp.gmail.com'
# EMAIL_HOST_USER = 'sithushuffle20@gmail.com'
# EMAIL_HOST_PASSWORD = 'sithu2762000'
# EMAIL_PORT = 587

EMAIL_HOST = 'smtp.mailtrap.io'
EMAIL_HOST_USER = '1f6938844f5a13'
EMAIL_HOST_PASSWORD = 'd5b9d12440c670'
EMAIL_PORT = '2525'