from django.forms import ModelForm
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from .models import *
from django import forms


from .models import Order


class OrderForm(ModelForm):
	class Meta:
		model = Order
		fields = '__all__'

class CreateUserForm(UserCreationForm):
	class Meta:
		model = User
		fields = ['username', 'email', 'password1', 'password2']

class ProductForm(forms.ModelForm):

    class Meta:
        model = Product
        fields = ["name", "category", "detail", "price",
                  "digital", "image", "discount"]
        widgets = {
            "title": forms.TextInput(attrs={
                "class": "form-control",
                "placeholder": "Enter the product title here..."
            }),
            "category": forms.Select(attrs={
                "class": "form-control",
				"placeholder": "Enter the product category here..."
            }),
			 "detail": forms.Textarea(attrs={
                "class": "form-control",
                "placeholder": "Description of the product...",
                "rows": 5
            }),
			"price": forms.NumberInput(attrs={
                "class": "form-control",
                "placeholder": "price of the product..."
            }),

            "image": forms.ClearableFileInput(attrs={
                "class": "form-control"
            })
            

        }


