from django.core.mail import send_mail
from django.conf import settings

def send_forget_password_mail(username, email):
    subject = 'your forget password link'
    message  = f'Hi {username}, click on the link to reset your password http://127.0.0.1:8000/change_password/'
    from_email = settings.EMAIL_HOST_USER
    recipient_list= [email]
    send_mail(subject, message, from_email, recipient_list)
    return True