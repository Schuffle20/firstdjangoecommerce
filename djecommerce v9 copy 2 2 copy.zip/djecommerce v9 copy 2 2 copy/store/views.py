from django.shortcuts import render, redirect
from django.http import JsonResponse
import json
import datetime
from .models import * 
from .utils import cookieCart, cartData, guestOrder

from django.views.generic import TemplateView, View, FormView, DetailView, ListView, CreateView
from django.db.models import Q


from django.forms import inlineformset_factory
from django.contrib.auth.forms import UserCreationForm

from django.contrib.auth import authenticate, login, logout

from store.models import Product

from django.contrib import messages

from django.contrib.auth.decorators import login_required
from django.urls import reverse_lazy, reverse
from django.template import RequestContext

from django.views.decorators.csrf import csrf_exempt
from .decorators import unauthenticated_user, allowed_users, admin_only

# Create your views here.
from .models import *
from .forms import *
from .filters import OrderFilter
from django.core.mail import EmailMessage, send_mail, BadHeaderError
from django.conf import settings
from django.template.loader import render_to_string

from django.contrib.auth.models import User
from django.contrib.auth import login, authenticate  
from django.contrib.sites.shortcuts import get_current_site  
from django.utils.encoding import force_bytes, force_str  
from django.utils.http import urlsafe_base64_encode, urlsafe_base64_decode  

from .tokens import generate_token

from .helpers import send_forget_password_mail
import uuid


def store(request):
    data = cartData(request)

    cartItems = data['cartItems']
    order = data['order']
    items = data['items']

    myFilter = OrderFilter()

    products = Product.objects.all()
    context = {'products':products, 'cartItems':cartItems, 'myFilter':myFilter}
    return render(request, 'store/store.html', context)
    
class SearchView(TemplateView):
    template_name = "store/search.html"

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        kw = self.request.GET.get("keyword")
        results = Product.objects.filter(
            Q(name__icontains=kw) | Q(price__icontains=kw) | Q(digital__icontains=kw))
        context["results"] = results
        return context

class OwlView(TemplateView):
    template_name = 'store/owl.html'

    def get_owl(self):
        name = self.request.GET.get('owl')
        results = Category.objects.filter(name=name)
        # context={"results":results1}
        context={'results':results}
        return context

# def collections(request):
#     category = Category.objects.filter(status=0)
#     # item = {
#     #         'name':category.name, 
#     #         'imageURL':product.imageURL
          
#     #         }
#     context = {'category':category}
#     return render(request, "store/collections.html", context)

def category_list(request):
    data = Category.objects.all().order_by('-id')
    context = {'data':data}
    return render(request, "store/category_list.html", context)

def category_product_list(request, cat_id):
    category = Category.objects.get(id=cat_id)
    data = Product.objects.filter(category=category).order_by('-id')
    # cats = Product.objects.distinct().values('category__name', 'category__id')
    context = {'data':data}
    return render(request, "store/category_product_list.html", context)

def product_detail(request, cat_id):
    data = Product.objects.get(id=cat_id)
    # cats = Product.objects.distinct().values('category__name', 'category__id')
    context = {'data':data}
    return render(request, "store/product_detail.html", context)

# def collectionsview(request, slug):
#     if(Category.objects.filter(slug=slug, status=0)):
#         products = Product.objects.filter(category__slug = slug)
#         category_name = Category.objects.filter(category__slug = slug).first()
#         context = {'products': products, 'category_name': category_name}
#         return render(request, 'store/products/index.html', context)
#     else:
#         messages.warning(request, "No such category found")
#         return redirect('collections')

# class OwlView(TemplateView):
#     template_name ="store/owl.html"
#     model = Product

#     def get_owl(self):
#         name = self.request.GET.get('owl')
#         results = self.model.objects.all()
#         if name:
# 			results = results.filter(name__icontains=name)
# 		context = {'results':results}
# 		return context

# def activateEmail(request, user, user_to)
# @csrf_exempt
# # @unauthenticated_user
# def registerPage(request):
#     if request.user.is_authenticated:
#         return redirect('store')
#     else:
#         form = CreateUserForm()
#         if request.method == 'POST':
#             form = CreateUserForm(request.POST)
#             if form.is_valid():
#                 form.save()
#                 username = form.cleaned_data.get('username')
#                 messages.success(request, 'Account was created for ' + username + email)
#                 return redirect('login')     
#         context = {'form':form}
#         return render(request, 'store/register.html', context)
# @csrf_exempt
def registerPage(request):
    if request.user.is_authenticated:
        return redirect('store')
    else:
        if request.method == 'POST':
            username = request.POST['username']
            email = request.POST['email']
            pass1 = request.POST['password1']
            pass2 = request.POST['password2']


            myuser = User.objects.create_user(username,email, pass1)
            myuser.save()
            messages.success(request, 'Account was created for ' + username)


            # subject = "Welcome to BuyIt Website"
            # message = "Hello " + myuser.username
            # from_email = settings.EMAIL_HOST_USER
            # to_list = [myuser.email,]
            # send_mail(subject, message, from_email, to_list, fail_silently=True)

            # Email Address Confirmation Email
            current_site = get_current_site(request)
            email_subject = "Confirm your Email @ GFG - Django Login!!"
            message2 = render_to_string('store/email_template.html',{
                
                'name': myuser.username,
                'domain': current_site.domain,
                'uid': urlsafe_base64_encode(force_bytes(myuser.pk)),
                'token': generate_token.make_token(myuser)
            })
            email = EmailMessage(
            email_subject,
            message2,
            settings.EMAIL_HOST_USER,
            [myuser.email],
            )
            email.fail_silently = True
            email.send()
            return redirect('login')     
        # context = {'form':form}
        return render(request, 'store/register.html')

def activate(request,uidb64,token):
    try:
        uid = force_str(urlsafe_base64_decode(uidb64))
        myuser = User.objects.get(pk=uid)
    except (TypeError,ValueError,OverflowError,User.DoesNotExist):
        myuser = None

    if myuser is not None and generate_token.check_token(myuser,token):
        myuser.is_active = True
        # user.profile.signup_confirmation = True
        myuser.save()
        login(request,myuser)
        messages.success(request, "Your Account has been activated!!")
        return redirect('login')
    else:
        return render(request,'store/activation_failed.html')

    


# @csrf_exempt
# @unauthenticated_user
def loginPage(request):
    
    if request.method == 'POST':
        username = request.POST.get('username')
        password =request.POST.get('password')

        user = authenticate(request, username=username, password=password)

        if user is not None:
            login(request, user)
            return redirect('store')
        else:
            messages.info(request, 'Username OR password is incorrect')

    context = {}
    return render(request, 'store/login.html', context)

def logoutUser(request):
    logout(request)
    return redirect('store')

# class PasswordForgotView(FormView):
#     template_name = "forgotpassword.html"
    # form_class = PasswordForgotForm
    # success_url = "/forgot-password/?m=s"

def ChangePassword(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        new_password =request.POST.get('password1')
        confirm_password =request.POST.get('password2')
        user = User.objects.filter(username=username)

        if user is None:
            messages.success(request, "No User is Found")
            return redirect('change-password')

        if new_password != confirm_password:
            messages.success(request, "Password do not match")
            return redirect('change-password')
        
        user_obj = User.objects.get(username=username)
        user_obj.set_password(new_password)
        user_obj.save()

        return redirect('login')
        # else:

    # context = {}
    # try:
    #     profile_obj = Profile.objects.get(forget_password_token=token)

    #     print(profile_obj)

    # except Exception as e:
    #     print(e)

    return render(request, "store/changepassword.html")

def PasswordForgot(request):
    try:

        if request.method == 'POST':
            username = request.POST.get('username')
            email =request.POST.get('email')

            if not User.objects.filter(username=username).first():
                    messages.success(request, "No user found with this username.")
                    return redirect('password-forgot')
            if not User.objects.filter(email=email):
                    messages.success(request, "Not user found with this email.")
                    return redirect('password-forgot')
            
            user_obj = User.objects.get(username=username)
            user_obj_email = User.objects.get(email=email)
            # token = str(uuid.uuid1())
            # profile_obj = Profile.objects.get(user = user_obj)
            # profile_obj.forget_password_token=token
            # profile_obj.save()
            # send_forget_password_mail(user_obj, user_obj_email)
            subject = 'your forget password link'
            message  = f'Hi {username}, click on the link to reset your password http://127.0.0.1:8000/change_password/'
            from_email = settings.EMAIL_HOST_USER
            recipient_list= [email]
            send_mail(subject, message, from_email, recipient_list)
            messages.success(request, "And email is sent.")
            return redirect('change-password')
    
    except Exception as e:
        print(e)
        
    return render(request, "store/forgotpassword.html")
        

# @unauthenticated_user
# @login_required(login_url='login')
def cart(request):
    data = cartData(request)

    cartItems = data['cartItems']
    order = data['order']
    items = data['items']
    products = data['products']

    context = {'items':items, 'order':order, 'cartItems':cartItems, 'products':products}
    return render(request, 'store/cart.html', context)

# @login_required(login_url='login')
def checkout(request):
    data = cartData(request)
    
    cartItems = data['cartItems']
    order = data['order']
    items = data['items']

    context = {'items':items, 'order':order, 'cartItems':cartItems}
    return render(request, 'store/checkout.html', context)

# @login_required(login_url='login')
def updateItem(request):
    data = json.loads(request.body)
    productId = data['productId']
    action = data['action']
    print('Action:', action)
    print('Product:', productId)

    customer = request.user.customer
    product = Product.objects.get(id=productId)
    order, created = Order.objects.get_or_create(customer=customer, complete=False)

    orderItem, created = OrderItem.objects.get_or_create(order=order, product=product)

    if action == 'add':
        orderItem.quantity = (orderItem.quantity + 1)
    elif action == 'remove':
        orderItem.quantity = (orderItem.quantity - 1)

    orderItem.save()

    if orderItem.quantity <= 0:
        orderItem.delete()

    return JsonResponse('Item was added', safe=False)

# @login_required(login_url='login')
def processOrder(request):
    transaction_id = datetime.datetime.now().timestamp()
    data = json.loads(request.body)

    if request.user.is_authenticated:
        customer = request.user.customer
        order, created = Order.objects.get_or_create(customer=customer, complete=False)
    # else:
    # 	customer, order = guestOrder(request, data)

        total = float(data['form']['total'])
        order.transaction_id = transaction_id

        if total == order.get_cart_total:
            order.complete = True
            order.order_status = "Order Received"
        order.save()

        if order.shipping == True:
            ShippingAddress.objects.create(
            customer=customer,
            order=order,
            address=data['shipping']['address'],
            city=data['shipping']['city'],
            state=data['shipping']['state'],
            zipcode=data['shipping']['zipcode'],
            )
    else:
        print("User is not logged in")

    return JsonResponse('Payment submitted..', safe=False)

#Customer Profile View
class CustomerProfileView(TemplateView):
    template_name="store/customerprofile.html"
    

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        customer = self.request.user.customer
        context['customer'] = customer
        orders = Order.objects.filter(customer=customer)
        shippingaddress = ShippingAddress.objects.filter(customer=customer).order_by("-id")
        context["orders"] = orders
        context["shippingaddress"] = shippingaddress
        return context

class CustomerOrderDetailView(DetailView):
    template_name = "store/customerorderdetail.html"
    model = Order
    context_object_name = "ord_obj"

    def dispatch(self, request, *args, **kwargs):
        if request.user.is_authenticated and Customer.objects.filter(user=request.user).exists():
            order_id = self.kwargs["pk"]
            order = Order.objects.get(id=order_id)
            if request.user.customer != order.customer:
                return redirect("profile")
        else:
            return redirect("/login/?next=/profile/")
        return super().dispatch(request, *args, **kwargs)
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        customer = self.request.user.customer
        # context['customer'] = customer
        # order_items = OrderItem.objects.all().order_by("-id")
        # context['order_items'] = order_items
        # orders = Order.objects.filter(customer=customer).order_by("-id")
        shippingaddress = ShippingAddress.objects.filter(customer=customer).order_by("-id")
        # context["orders"] = orders
        context["shippingaddress"] = shippingaddress
        return context

class OrderItemView(TemplateView):
    template_name = "store/customerorderitems.html"

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        customer = self.request.user.customer
        order = Order.objects.filter(customer=customer).order_by("-id")
        # context['customer'] = customer
        # order_items = OrderItem.objects.all()
        order_items = OrderItem.objects.filter(order__in=order)
        context['order_items'] = order_items
        # orders = Order.objects.filter(customer=customer).order_by("-id")
        # shippingaddress = ShippingAddress.objects.filter(customer=customer).order_by("-id")
        # # context["orders"] = orders
        # context["shippingaddress"] = shippingaddress
        return context

def AdminLoginView(request):
     if request.method == 'POST':
        username = request.POST.get('username')
        password =request.POST.get('password')

        user = authenticate(request, username=username, password=password)

        if user is not None and Admin.objects.filter(user=user).exists():
            login(request, user)
            return redirect('admin-home')

        else:
            messages.info(request, 'Username OR password is incorrect')

     return render(request, 'admin/admin_login.html')

def AdminHomeView(request):
        if request.user.is_authenticated and Admin.objects.filter(user=request.user).exists():
            # orders = Order.objects.filter(complete==False)
            pendingorders = Order.objects.all()
            context = {"pendingorders": pendingorders}
            return render(request, 'admin/admin_home.html', context)
        else:
            messages.info(request, 'You are not authorized')

class AdminOrderDetailView(DetailView):
    template_name = "admin/admin_order_detail.html"
    model = Order
    context_object_name = "ord_obj"
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        customer = self.request.user.customer
        shippingaddress = ShippingAddress.objects.filter(customer=customer).order_by("-id")
        context["shippingaddress"] = shippingaddress
        context["allstatus"] = ORDER_STATUS
        return context

def AdminOrderItemView(request):
    template_name = "admin/admin_order_items.html"
    if request.user.is_authenticated and Admin.objects.filter(user=request.user).exists():
            # pendingorders = Order.objects.filter(order_status="Order Received")
            orders = Order.objects.all()
            order_items = OrderItem.objects.filter(order__in=orders)
            # pendingorders = Order.objects.all()
            context = {"order_items": order_items}
            return render(request, template_name, context)

def AdminPendingView(request):
        if request.user.is_authenticated and Admin.objects.filter(user=request.user).exists():
            # orders = Order.objects.filter(complete==False)
            pendingorders = Order.objects.filter(order_status="Order Received")
            context = {"pendingorders": pendingorders}
            return render(request, 'admin/admin_pending.html', context)
        else:
            messages.info(request, 'You are not authorized')

def AdminPendingItemView(request):
    template_name = "admin/admin_pending_items.html"
    if request.user.is_authenticated and Admin.objects.filter(user=request.user).exists():
            pendingorders = Order.objects.filter(order_status="Order Received")
            # orders = Order.objects.all()
            order_items = OrderItem.objects.filter(order__in=pendingorders)
            # pendingorders = Order.objects.all()
            context = {"order_items": order_items}
            return render(request, template_name, context)

class AdminRequiredMixin(object):
    def dispatch(self, request, *args, **kwargs):
        if request.user.is_authenticated and Admin.objects.filter(user=request.user).exists():
            pass
        else:
            return redirect("admin-login")
        return super().dispatch(request, *args, **kwargs)

class AdminProductListView(AdminRequiredMixin, ListView):
    template_name = "admin/adminproductlist.html"
    queryset = Product.objects.all().order_by("-id")
    context_object_name = "allproducts"

class AdminOrderStatuChangeView(AdminRequiredMixin, View):
    def post(self, request, *args, **kwargs):
        order_id = self.kwargs["pk"]
        order_obj = Order.objects.get(id=order_id)
        new_status = request.POST.get("status")
        order_obj.order_status = new_status
        order_obj.save()
        return redirect(reverse_lazy("admin_order_detail", kwargs={"pk": order_id}))

class AdminProductCreateView(AdminRequiredMixin, CreateView):
    template_name = "admin/admin_product_create.html"
    form_class = ProductForm
    success_url = reverse_lazy("adminproductlist")

    def form_valid(self, form):
        p = form.save()
        # images = self.request.FILES.getlist("more_images")
        # for i in images:
        #     ProductImage.objects.create(product=p, image=i)
        return super().form_valid(form)



        


