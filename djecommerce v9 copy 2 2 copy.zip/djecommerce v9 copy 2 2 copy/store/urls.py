from django.contrib import admin
from django.urls import path
from . import views

from django.conf.urls.static import static
from django.conf import settings

from django.contrib.auth import views as auth_views

from .views import *

urlpatterns = [
	#Leave as empty string for base url
	path('', views.store, name="store"),
	path('register/', views.registerPage, name="register"),
	path('login/', views.loginPage, name="login"),  
	path('logout/', views.logoutUser, name="logout"),
	path('password_forgot/', views.PasswordForgot, name="password-forgot"),
	path('change_password/', views.ChangePassword, name="change-password"),

	# Password reset links (ref: https://github.com/django/django/blob/master/django/contrib/auth/views.py)
    # path('password_change/done/', auth_views.PasswordChangeDoneView.as_view(template_name='registration/password_change_done.html'), 
    #     name='password_change_done'),

    # path('password_change/', auth_views.PasswordChangeView.as_view(template_name='registration/password_change.html'), 
    #     name='password_change'),

    # path('password_reset/done/', auth_views.PasswordResetCompleteView.as_view(template_name='registration/password_reset_done.html'),
    #  name='password_reset_done'),

    # path('reset/<uidb64>/<token>/', auth_views.PasswordResetConfirmView.as_view(), name='password_reset_confirm'),
    # path('password_reset/', auth_views.PasswordResetView.as_view(), name='password_reset'),
    
    # path('reset/done/', auth_views.PasswordResetCompleteView.as_view(template_name='registration/password_reset_complete.html'),
    #  name='password_reset_complete'),
	




	path('cart/', views.cart, name="cart"),
	path('search/', SearchView.as_view(), name="search"),

	# path('collections/', views.collections, name="collections"),
	# path('collections/<str:slug>', views.collectionsview, name="collectionsview"),
	path('category_list',views.category_list,name='category-list'),
	path('category_product_list/<int:cat_id>',views.category_product_list,name='category-product-list'),
	path('product_detail/<int:cat_id>',views.product_detail,name='product-detail'),

	path('owlview/', OwlView.as_view(), name="owlview"),

	path('checkout/', views.checkout, name="checkout"),

	path('update_item/', views.updateItem, name="update_item"),
	path('process_order/', views.processOrder, name="process_order"),

	path('activate/<uidb64>/<token>', views.activate, name="activate"),

	#Customer Profile
	path('profile/', CustomerProfileView.as_view(), name="profile"),
	path('profile/order-<int:pk>', CustomerOrderDetailView.as_view(), name="customer_order_detail"),
	path('orderitems/', OrderItemView.as_view(), name="orderitems"),
	# path('orderitems/', views.OrderItemView, name="orderitems"),

		#Admin
	path('admin_login/', views.AdminLoginView, name="admin-login"),
	path('admin_home/', views.AdminHomeView, name="admin-home"),
	path('admin-order/<int:pk>', AdminOrderDetailView.as_view(), name="admin_order_detail"),
	path('admin_orderitems', views.AdminOrderItemView, name="admin-orderitems"),
	path('admin_pending/', views.AdminPendingView, name="admin-pending"),
	path('admin_pending_items/', views.AdminPendingItemView, name="admin-pending-items"),
	path("admin-order-<int:pk>-change/",
         AdminOrderStatuChangeView.as_view(), name="adminorderstatuschange"),
	path("admin-product/list/", AdminProductListView.as_view(),
         name="adminproductlist"),
    path("admin-product/add/", AdminProductCreateView.as_view(),
         name="adminproductcreate"),




]

urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)